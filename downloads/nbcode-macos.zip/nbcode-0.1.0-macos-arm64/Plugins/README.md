# 随仓库提供的插件

这里放的是可以直接安装的 `.nbplugin` 声明式插件包（JSON manifest，不执行代码）。

| 插件 | 语言 | 语言服务器 | 高亮 | 状态 |
| --- | --- | --- | --- | --- |
| `rust-analyzer.nbplugin` | Rust | `rust-analyzer` | 内置 tree-sitter | ✅ 已验证 |
| `clangd.nbplugin` | C / C++ | `clangd` | 内置 tree-sitter | ✅ 已验证 |
| `mypy.nbplugin` | Python | `pylsp` + `mypy-ls` | 内置 tree-sitter | ✅ 已验证 |
| `typescript.nbplugin` | TypeScript / TSX | `typescript-language-server` | 内置 tree-sitter | ✅ 已验证 |
| `ocaml.nbplugin` | OCaml | `ocamllsp` | 内置 tree-sitter | ✅ 已验证 |
| `lean4.nbplugin` | Lean 4 | `lean --server` | 无语法（纯 LSP） | ✅ 已验证 |
| `moonbit.nbplugin` | MoonBit | `moon-lsp --stdio` | 无语法（纯 LSP） | ✅ 已验证 |
| `swift.nbplugin` | Swift | `sourcekit-lsp` | 内置 tree-sitter | ✅ 已验证 |

服务器安装方式（本机都已装好；`/tmp/ocamldemo`、`/tmp/leandemo`、`/tmp/moondemo`、
`/tmp/tsdemo` 是可复现的 demo 工程）：

| 语言 | 安装方式 | 验证 |
| --- | --- | --- |
| TypeScript | `npm install -g typescript-language-server typescript`（装到 `~/.local/node/bin`）**项目里还需要 `typescript@5`**（`npm i -D typescript@5`），ts-ls 6 目前不支持 TS 7 | `zsh -lc 'typescript-language-server --version'` |
| OCaml | `opam install ocaml-lsp-server`（`~/.opam/default/bin/ocamllsp`） | `zsh -lc 'ocamllsp --version'` |
| Lean 4 | `elan` 安装 Lean（`~/.elan/bin/lean`），LSP 参数是 `--server` | `zsh -lc 'lean --version'` |
| MoonBit | MoonBit 工具链自带（`~/.moon/bin/moon-lsp`），LSP 参数是 `--stdio` | `zsh -lc 'moon-lsp --help'` |

## swift.nbplugin —— Swift 语言支持

- 语法高亮：复用 app 内置的 tree-sitter swift 语法；
- 诊断、悬停、补全、跳转定义来自 sourcekit-lsp（Xcode 工具链自带 /usr/bin/sourcekit-lsp）；
- 项目卡片：识别 Package.swift，提供编译 / 运行 / 调试 / 格式化
  （swift build / swift run / swift run / xcrun swift-format format --in-place --recursive .）；
- 单文件动作用于顶栏的「运行当前 Swift 文件」（swift <file>）。

## mypy.nbplugin —— Python 语言支持 + mypy 类型检查

- 语法高亮：复用 app 内置的 tree-sitter `python` 语法；
- 诊断：mypy 的类型错误（通过 `pylsp` 的 `mypy-ls` 插件提供）；
- 悬停、补全、跳转定义来自 `pylsp`。

### 为什么是 pylsp + mypy-ls

PyPI 上**没有**独立的 mypy 语言服务器（`mypy-language-server` / `mypy-lsp` 都不存在），
mypy 的 LSP 用法是「`pylsp` + `mypy-ls` 插件」。所以这个插件声明的是 `pylsp`，
mypy 作为 `pylsp` 的检查器运行。

### 安装服务器（一次）

```bash
VENV="$HOME/.local/share/nbcode/mypy-lsp"
/usr/local/bin/python3.13 -m venv "$VENV"
"$VENV/bin/python" -m pip install python-lsp-server mypy-ls mypy
mkdir -p "$HOME/.local/bin"
ln -sf "$VENV/bin/pylsp" "$HOME/.local/bin/pylsp"   # ~/.local/bin 在登录 shell PATH 里
```

验证：

```bash
zsh -lc 'which pylsp && pylsp --version'
```

### 安装插件

```bash
mkdir -p "$HOME/Library/Application Support/nbcode/Plugins"
cp -R Plugins/mypy.nbplugin "$HOME/Library/Application Support/nbcode/Plugins/"
pkill -9 -f 'nbcode.app/Contents/MacOS/nbcode'; open dist/nbcode.app
```

### 项目配置

插件的 `languageServers[0].initializationOptions` 已经把 `mypy_ls` 打开：

```json
{ "pylsp": { "plugins": { "mypy_ls": { "enabled": true } } } }
```

项目里只需要写 mypy 的规则（`pylsp` 会读取工作区根目录的配置）：

```toml
# pyproject.toml
[tool.mypy]
python_version = "3.13"
strict = true
```

也可以换成 `mypy.ini` / `setup.cfg`；插件声明的 `rootMarkers` 已经包含这些文件名。

### 可调项

| 键 | 现在的值 | 说明 |
| --- | --- | --- |
| `executable` | `pylsp` | 换别的 Python LSP（如 `pyright`）时改这里 |
| `rootMarkers` | pyproject.toml / mypy.ini / .mypy.ini / setup.cfg / setup.py / requirements.txt / .git | 决定工作目录 |
| `capabilities` | diagnostics / hover / completion / definition | 只开启想要的特性 |

> `initializationOptions` 会随 initialize 请求发给服务器（NBCore 的 JSON 值会转换成
> LSP SDK 的 JSON 类型），所以插件可以自带服务器配置，不要求用户改项目文件。

## rust-analyzer.nbplugin —— Rust 语言支持

- 语法高亮：内置 tree-sitter `rust` 语法；
- LSP：`rust-analyzer`（诊断、悬停、inlay hints），`rootMarkers` = `Cargo.toml`；
- 可执行文件优先找 app 内置的 `Contents/Resources/LanguageServers/rust-analyzer`，
  否则用 PATH 里的（`~/.cargo/bin/rust-analyzer`）。

### 安装

```bash
mkdir -p "$HOME/Library/Application Support/nbcode/Plugins"
cp -R Plugins/rust-analyzer.nbplugin "$HOME/Library/Application Support/nbcode/Plugins/"
pkill -9 -f 'nbcode.app/Contents/MacOS/nbcode'; open dist/nbcode.app
```

验证：

```bash
zsh -lc 'which rust-analyzer'
```

## clangd.nbplugin —— C / C++ 语言支持

- 语法高亮：复用 app 内置的 tree-sitter `cpp` / `c` 语法；
- LSP：clangd，提供诊断、悬停、补全、跳转定义；
- 语言服务器只需要一个可执行文件名字 `clangd`，宿主会按
  绝对路径 → 插件内相对路径 → app 内置 Resources → PATH → 登录 shell PATH 的顺序解析。

### 安装

```bash
mkdir -p "$HOME/Library/Application Support/nbcode/Plugins"
cp -R Plugins/clangd.nbplugin "$HOME/Library/Application Support/nbcode/Plugins/"
```

然后重启 nbcode（插件只在启动时扫描一次）：

```bash
pkill -9 -f 'nbcode.app/Contents/MacOS/nbcode'; open dist/nbcode.app
```

也可以在 设置 › 插件 › 安装插件… 里选择这个目录。

### clangd 从哪来

- Xcode 自带：`/usr/bin/clangd`（Xcode 命令行工具的 shim）
- 或 Homebrew LLVM：`brew install llvm`，然后在 PATH 里提供 clangd

检查：

```bash
zsh -lc 'which clangd && clangd --version'
```

### 可调项（plugin.json 的 contributes.languageServers[0]）

| 键 | 现在的值 | 说明 |
| --- | --- | --- |
| `arguments` | `["--background-index"]` | clangd 参数，例如加 `--clang-tidy`、`--header-insertion=never` |
| `rootMarkers` | `compile_commands.json`、`CMakeLists.txt`、`Makefile`、`meson.build`、`.clangd` | 决定 LSP 的工作目录 |
| `capabilities` | diagnostics/hover/completion/definition | 只开启想要的特性 |
| `fileExtensions` | .c .h .cpp .cc .cxx .c++ .hpp .hh .hxx | 触发语言服务器的文件 |

### 项目里的 clangd 索引

CMake 项目建议生成编译数据库，clangd 才有完整的诊断：

```bash
cmake -S . -B build -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
ln -sf build/compile_commands.json .
```## simpleHighlight —— 简易正则高亮

给没有编辑器语法（tree-sitter）或没有 LSP 的语言提供立即可见的高亮；
也可以给有语法的语言做首帧兜底：简单高亮先画出来，真正的语法高亮完成后覆盖它。

在 contributes.languages[] 里加 simpleHighlight：键是颜色，值是正则表达式字符串或字符串数组。

    "simpleHighlight": {
      "KeywordColor": "true|false|null",
      "StringColor": "[^\"]*",
      "NumberColor": "-?[0-9]+",
      "#0xC792EA": ["(if|else)", "(for|while)"],
      "#0x7F848E": "//.*$",
      "Color": "[A-Za-z_][A-Za-z0-9_-]*:"
    }

语义颜色（跟随当前编辑器主题，插件不要写死 light/dark 颜色）：

- KeywordColor / StringColor / CommentColor / NumberColor / TypeColor / FunctionColor
- Color：泛用兜底颜色（普通文本色）

字面量颜色支持 #RRGGBB、#RRGGBBAA、#0xRRGGBB、#0xRRGGBBAA 四种写法。
语义颜色的优先级高于字面量颜色：同一段文字同时命中时，关键字/字符串等语义色生效。

language 的 syntax 写 "none" 可以完全不用 tree-sitter，只使用 simpleHighlight
（仓库里的 json.nbplugin 就是这么做的，JSON/JSONC 文件立即有色，无需任何语言服务器）。

