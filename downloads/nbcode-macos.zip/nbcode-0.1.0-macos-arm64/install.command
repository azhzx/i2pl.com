#!/bin/bash
# nbcode installer: copies the app and its plugins into place.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
APP_SOURCE="$HERE/nbcode.app"

if [ ! -d "$APP_SOURCE" ]; then
  echo "找不到 nbcode.app，请把本脚本和 nbcode.app 放在同一个文件夹里。"
  read -r -p "按回车退出..."
  exit 1
fi

DEST="/Applications"
if [ ! -w "$DEST" ]; then
  DEST="$HOME/Applications"
  mkdir -p "$DEST"
fi

echo "==> 安装 nbcode.app 到 $DEST"
rm -rf "$DEST/nbcode.app"
cp -R "$APP_SOURCE" "$DEST/nbcode.app"

if [ -d "$HERE/Plugins" ]; then
  PLUGIN_DIR="$HOME/Library/Application Support/nbcode/Plugins"
  echo "==> 安装 Plugins 到 $PLUGIN_DIR"
  mkdir -p "$PLUGIN_DIR"
  cp -R "$HERE/Plugins/." "$PLUGIN_DIR/"
fi

echo "==> 移除 quarantine 标记"
xattr -dr com.apple.quarantine "$DEST/nbcode.app" 2>/dev/null || true

echo "==> 启动 nbcode"
open "$DEST/nbcode.app"

echo
echo "安装完成。以后可以从「应用程序」打开 nbcode。"
read -r -p "按回车退出..."
